
-- ============================================
-- V. FAZA - Tablica korisnik
-- Dodati u bazu stern_portal
-- ============================================

CREATE TABLE IF NOT EXISTS korisnik (
    id              INT(11)       NOT NULL AUTO_INCREMENT,
    ime             VARCHAR(32)   NOT NULL,
    prezime         VARCHAR(32)   NOT NULL,
    korisnicko_ime  VARCHAR(32)   NOT NULL UNIQUE,
    lozinka         VARCHAR(255)  NOT NULL,
    razina          TINYINT(1)    NOT NULL DEFAULT 0,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
