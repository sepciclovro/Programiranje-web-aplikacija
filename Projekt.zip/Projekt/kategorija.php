<?php
include 'connect.php';
define('UPLPATH', 'img/');

$kategorija = isset($_GET['kategorija']) ? mysqli_real_escape_string($dbc, $_GET['kategorija']) : 'politika';
$naslov_kat = strtoupper($kategorija);
?>
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stern - <?php echo htmlspecialchars($naslov_kat); ?></title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

    <header>
        <a href="index.php" class="logo">
            <img src="img/logo.jpg" alt="Stern Logo" class="logo-image">
        </a>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="kategorija.php?kategorija=politika"
                    <?php if ($kategorija === 'politika') echo 'class="active"'; ?>>Politik</a></li>
                <li><a href="kategorija.php?kategorija=zdravlje"
                    <?php if ($kategorija === 'zdravlje') echo 'class="active"'; ?>>Gesundheit</a></li>
                <li><a href="unos.php">Unos</a></li>
                <li><a href="administrator.php">Administracija</a></li>
            </ul>
        </nav>
    </header>

    <main class="wrapper">
        <h1 class="section-heading"><?php echo htmlspecialchars($naslov_kat); ?></h1>
        <div class="news-grid">
        <?php
        $query  = "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='$kategorija' ORDER BY id DESC";
        $result = mysqli_query($dbc, $query);
        while ($row = mysqli_fetch_array($result)) {
            echo '<article class="news-card">';
            echo '<a href="clanak.php?id=' . $row['id'] . '">';
            echo '<img src="' . UPLPATH . $row['slika'] . '" alt="' . htmlspecialchars($row['naslov']) . '" loading="lazy">';
            echo '</a>';
            echo '<span class="category-label">' . htmlspecialchars($row['kategorija']) . '</span>';
            echo '<h2><a href="clanak.php?id=' . $row['id'] . '">' . htmlspecialchars($row['naslov']) . '</a></h2>';
            echo '</article>';
        }
        ?>
        </div>
    </main>

    <footer>
        <p>Nachrichten vom 17.05.2019 | &copy; stern.de GmbH | <a href="index.php">Home</a></p>
        <p>Autor: Lovro Sepčić | 2026</p>
    </footer>

<?php mysqli_close($dbc); ?>
</body>
</html>
