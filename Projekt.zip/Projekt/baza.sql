-- ============================================
-- Baza: stern_portal
-- Kreirati u phpMyAdmin ili importati ovaj SQL
-- ============================================

CREATE DATABASE IF NOT EXISTS stern_portal
  CHARACTER SET utf8
  COLLATE utf8_general_ci;

USE stern_portal;

CREATE TABLE IF NOT EXISTS vijesti (
    id         INT(11)      NOT NULL AUTO_INCREMENT,
    datum      VARCHAR(32)  NOT NULL,
    naslov     VARCHAR(64)  NOT NULL,
    sazetak    TEXT         NOT NULL,
    tekst      TEXT         NOT NULL,
    slika      VARCHAR(64)  NOT NULL,
    kategorija VARCHAR(64)  NOT NULL,
    arhiva     TINYINT(1)   NOT NULL DEFAULT 0,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Testni podaci
INSERT INTO vijesti (datum, naslov, sazetak, tekst, slika, kategorija, arhiva) VALUES
('17.05.2019.', 'Margrethe Vestager lässt die Liberalen hoffen – und Trump zittern',
 'Margrethe Vestager gilt als die härteste Gegenspielerin von Konzernen wie Google und Amazon.',
 'Als Tech-Kritikerin und Vizepräsidentin der EU-Kommission macht Vestager seit Jahren Schlagzeilen. Nun mischt sie auch im Präsidentschaftsrennen mit.',
 'politika1.jpg', 'politika', 0),

('17.05.2019.', 'Einwanderung: Trump will mehr "total brillante" Leute und weniger Familienmitglieder',
 'US-Präsident Donald Trump hat einen neuen Einwanderungsplan vorgestellt, der auf Qualifikationen statt Familienbande setzt.',
 'Trump präsentierte in einer Rede im Rosengarten einen Plan, der die Zahl der Einwanderer mit Hochschulabschluss deutlich erhöhen soll. Kritiker sehen darin eine Abkehr von amerikanischen Werten.',
 'politika2.jpg', 'politika', 0),

('17.05.2019.', 'Entscheidung über E-Roller - darum geht es im Bundesrat',
 'Der Bundesrat entscheidet über die Zulassung von E-Scootern im Straßenverkehr.',
 'E-Roller sollen bald offiziell auf deutschen Straßen fahren dürfen. Der Bundesrat stimmt über die neue Elektrokleinstfahrzeuge-Verordnung ab.',
 'politika3.jpg', 'politika', 0),

('17.05.2019.', 'Abnehmen durch Sport und richtige Ernährung - Antworten auf häufige Fragen',
 'Gesund abnehmen ist kein Hexenwerk – wenn man die richtigen Tipps kennt.',
 'Viele Menschen kämpfen mit ihrem Gewicht. Experten erklären, wie Sport und Ernährung zusammenspielen müssen, damit die Kilos purzeln.',
 'zdravlje1.jpg', 'zdravlje', 0),

('17.05.2019.', 'Menschen in einer Parallelwelt, die nur einen Steinwurf entfernt liegt',
 'Eine Ausstellung zeigt das Leben an der deutschen Grenze – und wie nah sich Fremdes sein kann.',
 'Die Ausstellung No Borders – Grenzgang dokumentiert Leben und Alltag an den Rändern Europas. Ein bewegendes Porträt von Menschen zwischen zwei Welten.',
 'zdravlje2.jpg', 'zdravlje', 0),

('17.05.2019.', 'Mein Foto auf stern.de',
 'Leser schicken ihre besten Fotos ein – und die Redaktion wählt die schönsten aus.',
 'Jeden Monat präsentiert stern.de die eindrucksvollsten Leserfotos. Jetzt mitmachen und das eigene Bild in der Galerie sehen.',
 'zdravlje3.jpg', 'zdravlje', 0);
