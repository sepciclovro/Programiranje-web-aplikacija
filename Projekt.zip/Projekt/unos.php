<?php
session_start();
include 'connect.php';
define('UPLPATH', 'img/');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title    = $_POST['title'];
    $about    = $_POST['about'];
    $content  = $_POST['content'];
    $category = $_POST['category'];
    $archive  = isset($_POST['archive']) ? 1 : 0;
    $date     = date('d.m.Y.');
    $picture  = $_FILES['pphoto']['name'];

    if ($picture != '') {
        move_uploaded_file($_FILES['pphoto']['tmp_name'], 'img/' . $picture);
    } else {
        $picture = 'default.jpg';
    }

    $sql  = "INSERT INTO vijesti (datum, naslov, sazetak, tekst, slika, kategorija, arhiva) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, 'ssssssi', $date, $title, $about, $content, $picture, $category, $archive);
        mysqli_stmt_execute($stmt);
    }

    mysqli_close($dbc);
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stern - Unos vijesti</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

    <header>
        <a href="index.php" class="logo">
            <img src="img/logo.jpg" alt="Stern Logo" class="logo-image">
        </a>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="kategorija.php?kategorija=politika">Politik</a></li>
                <li><a href="kategorija.php?kategorija=zdravlje">Gesundheit</a></li>
                <li><a href="unos.php" class="active">Unos</a></li>
                <li><a href="administrator.php">Administracija</a></li>
            </ul>
        </nav>
    </header>

    <main class="wrapper">
        <h1 class="section-heading">UNOS VIJESTI</h1>

        <form name="unos_vijesti" action="unos.php" method="POST" enctype="multipart/form-data" autocomplete="on">
            <div class="form-item">
                <label for="title">Naslov vijesti</label>
                <div class="form-field">
                    <input type="text" name="title" id="title" class="form-field-textual" autofocus required>
                </div>
            </div>

            <div class="form-item">
                <label for="about">Kratki sadržaj vijesti (do 50 znakova)</label>
                <div class="form-field">
                    <textarea name="about" id="about" cols="30" rows="6" class="form-field-textual" required></textarea>
                </div>
            </div>

            <div class="form-item">
                <label for="content">Sadržaj vijesti</label>
                <div class="form-field">
                    <textarea name="content" id="content" cols="30" rows="12" class="form-field-textual" required></textarea>
                </div>
            </div>

            <div class="form-item">
                <label for="pphoto">Slika</label>
                <div class="form-field">
                    <input type="file" name="pphoto" id="pphoto" accept="image/jpg,image/jpeg,image/png,image/gif" class="input-text">
                </div>
            </div>

            <div class="form-item">
                <label for="category">Kategorija vijesti</label>
                <div class="form-field">
                    <select name="category" id="category" class="form-field-textual">
                        <option value="politika">Politik</option>
                        <option value="zdravlje">Gesundheit</option>
                        <option value="sport">Sport</option>
                        <option value="kultura">Kultura</option>
                    </select>
                </div>
            </div>

            <div class="form-item">
                <label for="archive">Spremiti u arhivu:</label>
                <div class="form-field">
                    <input type="checkbox" name="archive" id="archive">
                </div>
            </div>

            <div class="form-item">
                <button type="reset">Poništi</button>
                <button type="submit">Prihvati</button>
            </div>
        </form>
    </main>

    <footer>
        <p>Nachrichten vom 17.05.2019 | &copy; stern.de GmbH | <a href="index.php">Home</a></p>
        <p>Autor: Lovro Sepčić | 2026</p>
    </footer>

</body>
</html>
