<?php
include 'connect.php';
define('UPLPATH', 'img/');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$query  = "SELECT * FROM vijesti WHERE id=$id";
$result = mysqli_query($dbc, $query);
$row    = mysqli_fetch_array($result);
?>
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stern - <?php echo htmlspecialchars($row['naslov']); ?></title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

    <header>
        <a href="index.php" class="logo">
            <img src="img/logo.jpg" alt="Stern Logo" class="logo-image">
        </a>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="kategorija.php?kategorija=politika"
                    <?php if ($row['kategorija'] === 'politika') echo 'class="active"'; ?>>Politik</a></li>
                <li><a href="kategorija.php?kategorija=zdravlje"
                    <?php if ($row['kategorija'] === 'zdravlje') echo 'class="active"'; ?>>Gesundheit</a></li>
                <li><a href="unos.php">Unos</a></li>
                <li><a href="administrator.php">Administracija</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <article class="article-wrapper">

            <div class="row">
                <p class="article-category"><?php echo htmlspecialchars($row['kategorija']); ?></p>
                <h1 class="article-title"><?php echo htmlspecialchars($row['naslov']); ?></h1>
                <p class="article-meta">OBJAVLJENO: <?php echo htmlspecialchars($row['datum']); ?></p>
            </div>

            <div class="about">
                <p class="article-summary">
                    <?php echo nl2br(htmlspecialchars($row['sazetak'])); ?>
                </p>
            </div>

            <div class="slika">
                <img src="<?php echo UPLPATH . htmlspecialchars($row['slika']); ?>"
                     alt="<?php echo htmlspecialchars($row['naslov']); ?>"
                     class="article-image" loading="lazy">
            </div>

            <div class="sadrzaj">
                <p class="article-content">
                    <?php echo nl2br(htmlspecialchars($row['tekst'])); ?>
                </p>
            </div>

        </article>
    </main>

    <footer>
        <p>Nachrichten vom 17.05.2019 | &copy; stern.de GmbH | <a href="index.php">Home</a></p>
        <p>Autor: Lovro Sepčić | 2026</p>
    </footer>

<?php mysqli_close($dbc); ?>
</body>
</html>
