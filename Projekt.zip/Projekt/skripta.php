<?php
$title = isset($_POST['title']) ? $_POST['title'] : '';
$about = isset($_POST['about']) ? $_POST['about'] : '';
$content = isset($_POST['content']) ? $_POST['content'] : '';
$category = isset($_POST['category']) ? $_POST['category'] : '';
$archive = isset($_POST['archive']) ? 'Da' : 'Ne';

$image = '';
if (isset($_FILES['pphoto']) && $_FILES['pphoto']['name'] != '') {
    $image = $_FILES['pphoto']['name'];
} else {
    $image = 'default.jpg';
}
?>
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stern - Prikaz unosa</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

    <header>
        <a href="index.html" class="logo">
            <img src="img/logo.jpg" alt="Stern Logo" class="logo-image">
        </a>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="kategorija.html">Politik</a></li>
                <li><a href="index.html">Gesundheit</a></li>
                <li><a href="unos.html" class="active">Unos</a></li>
                <li><a href="administrator.php">Administracija</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <article class="article-wrapper">
            <div class="row">
                <p class="article-category"><?php echo htmlspecialchars($category); ?></p>
                <h1 class="article-title"><?php echo htmlspecialchars($title); ?></h1>
                <p class="article-meta">AUTOR: Redakcija | ARHIVA: <?php echo $archive; ?></p>
            </div>

            <div class="about">
                <p class="article-summary">
                    <?php echo nl2br(htmlspecialchars($about)); ?>
                </p>
            </div>

            <div class="slika">
                <img src="img/<?php echo htmlspecialchars($image); ?>" alt="Slika članka" class="article-image">
            </div>

            <div class="sadrzaj">
                <p class="article-content">
                    <?php echo nl2br(htmlspecialchars($content)); ?>
                </p>
            </div>
        </article>
    </main>

    <footer>
        <p>Nachrichten vom 17.05.2019 | &copy; stern.de GmbH | <a href="index.html">Home</a></p>
        <p>Autor: Lovro Sepčić | 2026</p>
    </footer>

</body>
</html>