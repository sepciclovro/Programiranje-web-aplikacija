<?php
session_start();
include 'connect.php';

$registriranKorisnik = '';
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ime      = $_POST['ime'];
    $prezime  = $_POST['prezime'];
    $username = $_POST['username'];
    $lozinka  = $_POST['pass'];
    $passRep  = $_POST['passRep'];
    $razina   = 0;

    if ($lozinka !== $passRep) {
        $msg = 'Lozinke nisu iste!';
    } else {
        $hashed_password = password_hash($lozinka, PASSWORD_BCRYPT);

        // Provjera postoji li korisnik s tim korisničkim imenom
        $sql = "SELECT korisnicko_ime FROM korisnik WHERE korisnicko_ime = ?";
        $stmt = mysqli_stmt_init($dbc);
        if (mysqli_stmt_prepare($stmt, $sql)) {
            mysqli_stmt_bind_param($stmt, 's', $username);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
        }

        if (mysqli_stmt_num_rows($stmt) > 0) {
            $msg = 'Korisničko ime već postoji!';
        } else {
            // Registracija korisnika - prepared statement
            $sql = "INSERT INTO korisnik (ime, prezime, korisnicko_ime, lozinka, razina) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_stmt_init($dbc);
            if (mysqli_stmt_prepare($stmt, $sql)) {
                mysqli_stmt_bind_param($stmt, 'ssssi', $ime, $prezime, $username, $hashed_password, $razina);
                mysqli_stmt_execute($stmt);
                $registriranKorisnik = true;
            }
        }
        mysqli_close($dbc);
    }
}
?>
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stern - Registracija</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

    <header>
        <a href="index.php" class="logo">
            <img src="img/logo.jpg" alt="Stern Logo" class="logo-image">
        </a>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="kategorija.php?kategorija=politika">Politik</a></li>
                <li><a href="kategorija.php?kategorija=zdravlje">Gesundheit</a></li>
                <li><a href="unos.php">Unos</a></li>
                <li><a href="administrator.php" class="active">Administracija</a></li>
            </ul>
        </nav>
    </header>

    <main class="wrapper">

    <?php if ($registriranKorisnik == true): ?>
        <div class="login-wrapper">
            <p style="color:green; font-weight:bold;">Korisnik je uspješno registriran!</p>
            <p><a href="administrator.php">Povratak na prijavu</a></p>
        </div>
    <?php else: ?>
        <div class="login-wrapper">
            <h1 class="section-heading" style="font-size:18px; margin-top:0;">REGISTRACIJA</h1>

            <form enctype="multipart/form-data" action="registracija.php" method="POST">
                <div class="form-item">
                    <span id="porukaIme" class="bojaPoruke"></span>
                    <label for="ime">Ime:</label>
                    <div class="form-field">
                        <input type="text" name="ime" id="ime" class="form-field-textual">
                    </div>
                </div>

                <div class="form-item">
                    <span id="porukaPrezime" class="bojaPoruke"></span>
                    <label for="prezime">Prezime:</label>
                    <div class="form-field">
                        <input type="text" name="prezime" id="prezime" class="form-field-textual">
                    </div>
                </div>

                <div class="form-item">
                    <span id="porukaUsername" class="bojaPoruke"></span>
                    <label for="username">Korisničko ime:</label>
                    <?php if ($msg): ?>
                        <br><span class="bojaPoruke"><?php echo $msg; ?></span>
                    <?php endif; ?>
                    <div class="form-field">
                        <input type="text" name="username" id="username" class="form-field-textual">
                    </div>
                </div>

                <div class="form-item">
                    <span id="porukaPass" class="bojaPoruke"></span>
                    <label for="pass">Lozinka:</label>
                    <div class="form-field">
                        <input type="password" name="pass" id="pass" class="form-field-textual">
                    </div>
                </div>

                <div class="form-item">
                    <span id="porukaPassRep" class="bojaPoruke"></span>
                    <label for="passRep">Ponovite lozinku:</label>
                    <div class="form-field">
                        <input type="password" name="passRep" id="passRep" class="form-field-textual">
                    </div>
                </div>

                <div class="form-item">
                    <button type="submit" id="slanje">Registriraj se</button>
                </div>
            </form>
        </div>
    <?php endif; ?>

    </main>

    <footer>
        <p>Nachrichten vom 17.05.2019 | &copy; stern.de GmbH | <a href="index.php">Home</a></p>
        <p>Autor: Lovro Sepčić | 2026</p>
    </footer>

    <script type="text/javascript">
    document.getElementById("slanje").onclick = function(event) {
        var slanjeForme = true;

        var poljeIme = document.getElementById("ime");
        var ime = document.getElementById("ime").value;
        if (ime.length == 0) {
            slanjeForme = false;
            poljeIme.style.border = "1px dashed red";
            document.getElementById("porukaIme").innerHTML = "<br>Unesite ime!<br>";
        } else {
            poljeIme.style.border = "1px solid green";
            document.getElementById("porukaIme").innerHTML = "";
        }

        var poljePrezime = document.getElementById("prezime");
        var prezime = document.getElementById("prezime").value;
        if (prezime.length == 0) {
            slanjeForme = false;
            poljePrezime.style.border = "1px dashed red";
            document.getElementById("porukaPrezime").innerHTML = "<br>Unesite Prezime!<br>";
        } else {
            poljePrezime.style.border = "1px solid green";
            document.getElementById("porukaPrezime").innerHTML = "";
        }

        var poljeUsername = document.getElementById("username");
        var username = document.getElementById("username").value;
        if (username.length == 0) {
            slanjeForme = false;
            poljeUsername.style.border = "1px dashed red";
            document.getElementById("porukaUsername").innerHTML = "<br>Unesite korisničko ime!<br>";
        } else {
            poljeUsername.style.border = "1px solid green";
            document.getElementById("porukaUsername").innerHTML = "";
        }

        var poljePass    = document.getElementById("pass");
        var pass         = document.getElementById("pass").value;
        var poljePassRep = document.getElementById("passRep");
        var passRep      = document.getElementById("passRep").value;
        if (pass.length == 0 || passRep.length == 0 || pass != passRep) {
            slanjeForme = false;
            poljePass.style.border    = "1px dashed red";
            poljePassRep.style.border = "1px dashed red";
            document.getElementById("porukaPass").innerHTML    = "<br>Lozinke nisu iste!<br>";
            document.getElementById("porukaPassRep").innerHTML = "<br>Lozinke nisu iste!<br>";
        } else {
            poljePass.style.border    = "1px solid green";
            poljePassRep.style.border = "1px solid green";
            document.getElementById("porukaPass").innerHTML    = "";
            document.getElementById("porukaPassRep").innerHTML = "";
        }

        if (slanjeForme != true) {
            event.preventDefault();
        }
    };
    </script>

</body>
</html>
