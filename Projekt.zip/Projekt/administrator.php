<?php
session_start();
include 'connect.php';
define('UPLPATH', 'img/');

$uspjesnaPrijava = false;
$admin = false;
$imeKorisnika = '';

if (isset($_POST['prijava'])) {
    $prijavaImeKorisnika     = $_POST['username'];
    $prijavaLozinkaKorisnika = $_POST['lozinka'];

    $sql  = "SELECT korisnicko_ime, lozinka, razina FROM korisnik WHERE korisnicko_ime = ?";
    $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, 's', $prijavaImeKorisnika);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
    }
    mysqli_stmt_bind_result($stmt, $imeKorisnika, $lozinkaKorisnika, $levelKorisnika);
    mysqli_stmt_fetch($stmt);

    if (mysqli_stmt_num_rows($stmt) > 0 && password_verify($prijavaLozinkaKorisnika, $lozinkaKorisnika)) {
        $uspjesnaPrijava = true;
        $admin = ($levelKorisnika >= 1);
        $_SESSION['username'] = $imeKorisnika;
        $_SESSION['level']    = $levelKorisnika;
    } else {
        $uspjesnaPrijava = false;
    }
}

if (isset($_GET['odjava'])) {
    session_destroy();
    header('Location: administrator.php');
    exit;
}

if (isset($_POST['delete']) && (($uspjesnaPrijava && $admin) || (isset($_SESSION['level']) && $_SESSION['level'] >= 1))) {
    $id   = (int)$_POST['id'];
    $sql  = "DELETE FROM vijesti WHERE id = ?";
    $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, 'i', $id);
        mysqli_stmt_execute($stmt);
    }
    header('Location: administrator.php');
    exit;
}

if (isset($_POST['update']) && (($uspjesnaPrijava && $admin) || (isset($_SESSION['level']) && $_SESSION['level'] >= 1))) {
    $id       = (int)$_POST['id'];
    $title    = $_POST['title'];
    $about    = $_POST['about'];
    $content  = $_POST['content'];
    $category = $_POST['category'];
    $archive  = isset($_POST['archive']) ? 1 : 0;
    $picture  = $_FILES['pphoto']['name'];

    if ($picture != '') {
        move_uploaded_file($_FILES['pphoto']['tmp_name'], 'img/' . $picture);
    } else {
        // Zadrži staru sliku - prepared statement
        $sql_old  = "SELECT slika FROM vijesti WHERE id = ?";
        $stmt_old = mysqli_stmt_init($dbc);
        if (mysqli_stmt_prepare($stmt_old, $sql_old)) {
            mysqli_stmt_bind_param($stmt_old, 'i', $id);
            mysqli_stmt_execute($stmt_old);
            mysqli_stmt_bind_result($stmt_old, $picture);
            mysqli_stmt_fetch($stmt_old);
        }
    }

    $sql  = "UPDATE vijesti SET naslov=?, sazetak=?, tekst=?, slika=?, kategorija=?, arhiva=? WHERE id=?";
    $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, 'sssssii', $title, $about, $content, $picture, $category, $archive, $id);
        mysqli_stmt_execute($stmt);
    }

    header('Location: administrator.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stern - Administracija</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

    <header>
        <a href="index.php" class="logo">
            <img src="img/logo.jpg" alt="Stern Logo" class="logo-image">
        </a>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="kategorija.php?kategorija=politika">Politik</a></li>
                <li><a href="kategorija.php?kategorija=zdravlje">Gesundheit</a></li>
                <li><a href="unos.php">Unos</a></li>
                <li><a href="administrator.php" class="active">Administracija</a></li>
            </ul>
        </nav>
    </header>

    <main class="wrapper">

    <?php

    if (($uspjesnaPrijava == true && $admin == true) ||
        (isset($_SESSION['level']) && $_SESSION['level'] >= 1)):
    ?>
        <h1 class="section-heading" style="margin-bottom:16px;">
            ADMINISTRACIJA
            <span style="font-size:13px; font-weight:normal;">
                &mdash; Prijavljeni: <?php echo htmlspecialchars($_SESSION['username'] ?? $imeKorisnika); ?>
                | <a href="administrator.php?odjava=1">Odjavi se</a>
            </span>
        </h1>

        <?php
        $sql    = "SELECT * FROM vijesti ORDER BY id DESC";
        $stmt   = mysqli_stmt_init($dbc);
        $result = mysqli_query($dbc, $sql);
        while ($row = mysqli_fetch_array($result)):
        ?>
        <form enctype="multipart/form-data" action="administrator.php" method="POST" class="admin-form-wrapper">
            <p class="admin-form-meta">
                ID: <strong><?php echo $row['id']; ?></strong> &nbsp;|&nbsp;
                Datum: <strong><?php echo htmlspecialchars($row['datum']); ?></strong> &nbsp;|&nbsp;
                Kategorija: <strong><?php echo htmlspecialchars($row['kategorija']); ?></strong>
            </p>

            <div class="form-item">
                <label>Naslov vijesti:</label>
                <div class="form-field">
                    <input type="text" name="title" class="form-field-textual"
                           value="<?php echo htmlspecialchars($row['naslov']); ?>">
                </div>
            </div>

            <div class="form-item">
                <label>Kratki sadržaj:</label>
                <div class="form-field">
                    <textarea name="about" cols="30" rows="4"
                        class="form-field-textual"><?php echo htmlspecialchars($row['sazetak']); ?></textarea>
                </div>
            </div>

            <div class="form-item">
                <label>Sadržaj vijesti:</label>
                <div class="form-field">
                    <textarea name="content" cols="30" rows="8"
                        class="form-field-textual"><?php echo htmlspecialchars($row['tekst']); ?></textarea>
                </div>
            </div>

            <div class="form-item">
                <label>Slika:</label>
                <div class="form-field">
                    <input type="file" class="input-text" name="pphoto">
                    <br>
                    <img src="<?php echo UPLPATH . htmlspecialchars($row['slika']); ?>"
                         width="100" style="margin-top:6px;">
                </div>
            </div>

            <div class="form-item">
                <label>Kategorija vijesti:</label>
                <div class="form-field">
                    <select name="category" class="form-field-textual">
                        <option value="politika" <?php if($row['kategorija']=='politika') echo 'selected'; ?>>Politik</option>
                        <option value="zdravlje" <?php if($row['kategorija']=='zdravlje') echo 'selected'; ?>>Gesundheit</option>
                        <option value="sport"    <?php if($row['kategorija']=='sport')    echo 'selected'; ?>>Sport</option>
                        <option value="kultura"  <?php if($row['kategorija']=='kultura')  echo 'selected'; ?>>Kultura</option>
                    </select>
                </div>
            </div>

            <div class="form-item">
                <label>Arhivirano:
                    <input type="checkbox" name="archive" <?php if($row['arhiva']==1) echo 'checked'; ?>>
                </label>
            </div>

            <div class="form-item">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <button type="reset">Poništi</button>
                <button type="submit" name="update">Izmjeni</button>
                <button type="submit" name="delete"
                        onclick="return confirm('Obrisati ovu vijest?')">Izbriši</button>
            </div>
        </form>
        <?php endwhile; ?>

    <?php
  
    elseif (($uspjesnaPrijava == true && $admin == false) ||
            (isset($_SESSION['level']) && $_SESSION['level'] == 0)):
    ?>
        <div class="login-wrapper">
            <p class="bojaPoruke">
                Bok <?php echo htmlspecialchars($_SESSION['username'] ?? $imeKorisnika); ?>!
                Nemate dovoljna prava za pristup ovoj stranici.
            </p>
            <p><a href="administrator.php?odjava=1">Odjavi se</a></p>
        </div>

    <?php
    // SLUČAJ 3: Nije prijavljen / pogrešni podaci
    else:
    ?>
        <div class="login-wrapper">
            <h1 class="section-heading" style="font-size:18px; margin-top:0;">PRIJAVA</h1>

            <?php if ($uspjesnaPrijava === false && isset($_POST['prijava'])): ?>
                <p class="bojaPoruke">
                    Pogrešno korisničko ime ili lozinka.
                    Morate se prvo <a href="registracija.php">registrirati</a>.
                </p>
            <?php endif; ?>

            <form action="administrator.php" method="POST">
                <div class="form-item">
                    <label for="username">Korisničko ime:</label>
                    <div class="form-field">
                        <input type="text" name="username" id="username" class="form-field-textual">
                    </div>
                </div>
                <div class="form-item">
                    <label for="lozinka">Lozinka:</label>
                    <div class="form-field">
                        <input type="password" name="lozinka" id="lozinka" class="form-field-textual">
                    </div>
                </div>
                <div class="form-item">
                    <button type="submit" name="prijava">Prijavi se</button>
                </div>
            </form>

            <p style="margin-top:14px; font-size:13px;">
                Nemate račun? <a href="registracija.php">Registrirajte se</a>
            </p>
        </div>

    <?php endif; ?>

    </main>

    <footer>
        <p>Nachrichten vom 17.05.2019 | &copy; stern.de GmbH | <a href="index.php">Home</a></p>
        <p>Autor: Lovro Sepčić | 2026</p>
    </footer>

<?php mysqli_close($dbc); ?>
</body>
</html>
